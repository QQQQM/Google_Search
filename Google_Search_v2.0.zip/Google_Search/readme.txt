# 运行方法  #
配置好config文件后直接点击 Google_Search.exe 即可

# 环境配置  #
要求安装好Google Chrome 浏览器 且 chromedriver 版本与浏览器版本对应

# config说明 # 
1、save_folder 保存文件的位置
2、driver_path 为chromedriver文件存放的位置
3、scolar_url 进行Google学术搜索的网站
4、search_url 进行作者+关键词搜索的网站（默认为必应搜索）
5、key_word_1 搜索的关键词
6、sleep_time 网页中每次操作后等待的时间（2s）
7、page_num 对关键词提取的词条数目（不是页数！）
8、year 检索时年份限制（0为不限制）
9、no_window 是否展示浏览器窗口（True为不展示，False为展示）
10、xpath 定位词条位置辅助
11、several_name指定“多”的那一部分的查找名
12、one_name指定“单”的那一部分的查找名


#  2020.3.14 #

# @Author: qimeng
# @File  : readme.txt
